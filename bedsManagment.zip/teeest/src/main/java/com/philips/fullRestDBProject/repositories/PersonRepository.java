package com.philips.fullRestDBProject.repositories;

import org.springframework.data.repository.CrudRepository;

import com.philips.fullRestDBProject.Beans.Person;


public interface PersonRepository extends CrudRepository<Person, Integer> {
	public Person findById(int id);
}
