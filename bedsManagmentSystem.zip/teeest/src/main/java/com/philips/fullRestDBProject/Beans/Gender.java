package com.philips.fullRestDBProject.Beans;

public enum Gender {
	Male, Female, unknown
}
