package com.philips.fullRestDBProject.services;
import org.springframework.beans.factory.annotation.Autowired;

import com.philips.fullRestDBProject.Beans.Person;
import com.philips.fullRestDBProject.repositories.PatientRepository;
import com.philips.fullRestDBProject.repositories.PersonRepository;


public class PatientsManager {

	@Autowired
	private PersonRepository personRepo;
	
	@Autowired
	private PatientRepository patientsRepo;
	
	
	public void addPerson(Person person) throws Exception
	{
		Person existing = this.personRepo.findById(person.getId());
		if(existing!=null)
		{
			throw new Exception("Product with id "+person.getId()+" already exists");
		}
		this.personRepo.save(person);
	}
	
	public void removePerson(int persontId) {
		this.personRepo.deleteById(persontId);
	}
	
	public Iterable<Person> getAllPersons() {		
		return this.personRepo.findAll();
	}
}
