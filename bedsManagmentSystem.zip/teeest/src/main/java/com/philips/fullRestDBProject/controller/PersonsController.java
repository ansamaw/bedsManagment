package com.philips.fullRestDBProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.philips.fullRestDBProject.Beans.Person;
import com.philips.fullRestDBProject.services.PatientsManager;


@RestController
@RequestMapping("persons")
public class PersonsController {

	@Autowired
	private PatientsManager patientsManager;
	
	@GetMapping("all")
	public Iterable<Person> getAll()
	{
		return this.patientsManager.getAllPersons();
	}

	
	@PostMapping("add")
	public ResponseEntity<?> addPerson(@RequestBody Person person)
	{
		try {
			patientsManager.addPerson(person);
			return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		} catch (Exception e) {
			return new ResponseEntity<Exception>(e,HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}
	
	
	@DeleteMapping("remove")
	public ResponseEntity<?> removePerson( int personId)
	{		
		patientsManager.removePerson(personId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
}
