package com.philips.fullRestDBProject.beans;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class ResultJson {	
	private String help;
	
	private Results result;

}
