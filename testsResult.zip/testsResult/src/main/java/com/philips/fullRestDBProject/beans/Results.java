package com.philips.fullRestDBProject.beans;



import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Results {
	
	private int limit;
	
	private Records[] records;
}
