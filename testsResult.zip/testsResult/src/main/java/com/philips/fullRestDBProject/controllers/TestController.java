package com.philips.fullRestDBProject.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.philips.fullRestDBProject.BL.TestsBL;
import com.philips.fullRestDBProject.beans.Records;

@RestController
@RequestMapping("test")
public class TestController {
	
	//private static String URL ="https://jsonplaceholder.typicode.com/users";
	private static String URL ="https://data.gov.il/api/3/action/datastore_search?resource_id=a9588029-8dd6-4c6f-b4ff-e8ca6413642f&limit=5";
	@Autowired
	RestTemplate httpClient;
	
	
	@Autowired
	TestsBL testsBL;

	@GetMapping("getUsers")
	public ResponseEntity<String> getRemoteData()
	{
		ResponseEntity<String> res = this.httpClient.getForEntity(URL, String.class);		
		System.out.println(res);				
		return res;
	}
	
	@GetMapping("download")
	public ResponseEntity<Void> downloadUsers()
	{
		testsBL.downloadAndSaveUsers();
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@GetMapping("getAll")
	public ResponseEntity<List<Records>> getAll()
	{
		List<Records> users =  testsBL.getAll();		
		return new ResponseEntity<List<Records>>(users, HttpStatus.OK); 
	}

}
