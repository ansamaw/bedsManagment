package com.philips.fullRestDBProject.BL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.philips.fullRestDBProject.beans.Records;
import com.philips.fullRestDBProject.beans.ResultJson;
import com.philips.fullRestDBProject.repositories.UsersRepo;

@Service
public class TestsBL {
	private static String URL ="https://data.gov.il/api/3/action/datastore_search?resource_id=a9588029-8dd6-4c6f-b4ff-e8ca6413642f&limit=5";
	
	
	@Autowired
	UsersRepo repo;
	
	@Autowired
	RestTemplate httpClient;
	
	
	public void downloadAndSaveUsers()
	{
		System.out.println("Downloading users");
		ResponseEntity<ResultJson> usersResponse = this.httpClient.getForEntity(URL, ResultJson.class);
		
		ResultJson resultsJson = usersResponse.getBody();
		
		System.out.println("Download completed, Now saving to DB");
		for(Records user : resultsJson.getResult().getRecords())
		{
			repo.save(user);
		}
		System.out.println("Download and save completed");
	}


	public List<Records> getAll() {		
		return repo.findAll();
	}
}
