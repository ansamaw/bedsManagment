package com.philips.fullRestDBProject.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import lombok.Data;

@Entity
@Data
public class Records {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int recordId;
	private int _id;
	private String result_date;
	private String corona_result;
	private String test_for_corona_diagnosis;
	private boolean is_first_Test;
}
