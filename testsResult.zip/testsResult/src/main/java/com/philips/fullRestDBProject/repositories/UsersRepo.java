package com.philips.fullRestDBProject.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.philips.fullRestDBProject.beans.Records;

public interface UsersRepo extends JpaRepository<Records, Integer>{

}
