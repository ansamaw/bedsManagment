package com.philips.fullRestDBProject.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.philips.fullRestDBProject.BL.UsersBL;
import com.philips.fullRestDBProject.beans.User;

@RestController
@RequestMapping("test")
public class TestController {

	private static String URL ="https://raw.githubusercontent.com/ansamaw/israel-cities/main/israel-cities.json";
	//private static String URL ="https://jsonplaceholder.typicode.com/users";
	//private static String URL ="https://data.gov.il/api/3/action/datastore_search?resource_id=a9588029-8dd6-4c6f-b4ff-e8ca6413642f&limit=5"
	@Autowired
	RestTemplate httpClient;


	@Autowired
	UsersBL usersBL;

	@GetMapping("getUsers")
	public ResponseEntity<String> getRemoteData()
	{

		httpClient = new RestTemplate();
		MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
		mappingJackson2HttpMessageConverter.setSupportedMediaTypes(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM));
		httpClient.getMessageConverters().add(mappingJackson2HttpMessageConverter);

		ResponseEntity<String> res = this.httpClient.getForEntity(URL, String.class);		
		System.out.println(res);				
		return res;
	}

	@GetMapping("download")
	public ResponseEntity<Void> downloadUsers()
	{
		usersBL.downloadAndSaveUsers();
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@GetMapping("getAll")
	public ResponseEntity<List<User>> getAll()
	{
		List<User> users =  usersBL.getAll();		
		return new ResponseEntity<List<User>>(users, HttpStatus.OK); 
	}

}
