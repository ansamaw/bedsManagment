package com.philips.fullRestDBProject.Beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Hospital {
	
	@Id
	private int id;
	private String name;
	private int maxOccupied;
	private int availableOccupied;
	private Status status;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "area_city")
	private Area area;
	private String email;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "hospital")
	private List<Patient> Patients;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "hospital")
	private List<Status> statuses;
	

	public void addPatient(Patient patient) {
		this.Patients.add(patient);
	}
	
	public void addStatus(Status status) {
		this.statuses.add(status);
	}
}
