package com.philips.fullRestDBProject.Beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Area {
	
	@Id
	private String city;
	private String zone;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<Person> Persons;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<Hospital> Hospitals;
	
	//------------------------------------------------ functions -----------------------
	public void addHospital(Hospital hospital)
	{
		Hospitals.add(hospital);
	}
	public void addPerson(Person person)
	{
		Persons.add(person);
	}
	
	//result = positive or negative
	public List<Person> getPersonsByGender(Gender gender){
		List<Person> temp = new ArrayList<>();
		for (Person person : temp) {
			if(person.getGender().equals(gender)) {
				temp.add(person);
			}
		}
		return temp;
	}
	
}
