package com.philips.fullRestDBProject.Beans;

public enum Color {
	Yellow, Red, Green
}
